"use client"

import { useEffect, useRef } from "react"
import Globe from "globe.gl"
import * as THREE from "three"

interface GlobePoint {
  id: string
  lat: number
  lng: number
  username: string
  message: string
  createdAt: number
  size: number
}

interface GlobeProps {
  points: GlobePoint[]
}

export function GlobeComponent({ points }: GlobeProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const globeRef = useRef<any>(null)
  const pointsMapRef = useRef<Map<string, GlobePoint>>(new Map())

  useEffect(() => {
    if (!containerRef.current) return

    // Initialize Globe.gl
    const globe = new Globe(containerRef.current)
      .globeImageUrl("/earth-dark.jpg")
      .backgroundColor("#000000")
      .showAtmosphere(true)
      .atmosphereColor("#0099ff")
      .atmosphereAltitude(0.15)

    globeRef.current = globe

    // Auto-rotate when idle
    let rotationTimeout: NodeJS.Timeout
    const resetRotation = () => {
      clearTimeout(rotationTimeout)
      rotationTimeout = setTimeout(() => {
        globe.controls().autoRotate = true
        globe.controls().autoRotateSpeed = 0.5
      }, 5000) // Start auto-rotate after 5 seconds of inactivity
    }

    globe.controls().addEventListener("start", () => {
      globe.controls().autoRotate = false
      resetRotation()
    })

    globe.controls().addEventListener("end", resetRotation)

    // Set initial camera
    globe.camera().position.z = 250

    // Handle window resize
    const handleResize = () => {
      if (containerRef.current) {
        globe.width(containerRef.current.clientWidth)
        globe.height(containerRef.current.clientHeight)
      }
    }

    window.addEventListener("resize", handleResize)

    return () => {
      window.removeEventListener("resize", handleResize)
      clearTimeout(rotationTimeout)
      globe.unobserveResize()
    }
  }, [])

  // Update points on the globe
  useEffect(() => {
    if (!globeRef.current) return

    const now = Date.now()
    const fadeOutDuration = 3000 // Fade out over 3 seconds before disappearing
    const visibleDuration = 30000 // Total 30 seconds before removal

    // Update point map and remove old ones
    const idsToRemove: string[] = []
    pointsMapRef.current.forEach((point, id) => {
      if (now - point.createdAt > visibleDuration) {
        idsToRemove.push(id)
      }
    })
    idsToRemove.forEach((id) => pointsMapRef.current.delete(id))

    // Add new points
    points.forEach((point) => {
      if (!pointsMapRef.current.has(point.id)) {
        pointsMapRef.current.set(point.id, point)
      }
    })

    // Convert to array and calculate opacity
    const pointsArray = Array.from(pointsMapRef.current.values()).map((point) => {
      const age = now - point.createdAt
      let opacity = 1

      if (age > visibleDuration - fadeOutDuration) {
        opacity = Math.max(0, 1 - (age - (visibleDuration - fadeOutDuration)) / fadeOutDuration)
      }

      return {
        ...point,
        opacity,
      }
    })

    // Update globe points
    globeRef.current
      .pointsData(pointsArray)
      .pointColor((d: any) => {
        // Neon cyan/blue color with opacity
        const color = new THREE.Color("#00ffff")
        return `rgba(0, 255, 255, ${d.opacity})`
      })
      .pointSize((d: any) => d.size * (0.5 + d.opacity))
      .pointsData(pointsArray)

    // Update labels for hover effect
    globeRef.current.pointLabel((d: any) => {
      return `<div class="text-xs text-white">
        <div class="font-bold">${d.username}</div>
        <div class="text-gray-400">${d.message}</div>
      </div>`
    })
  }, [points])

  return (
    <div
      ref={containerRef}
      className="w-full h-full rounded-lg overflow-hidden border border-cyan-500/20"
      style={{ minHeight: "400px" }}
    />
  )
}
